use strict;
if(@ARGV<7){
	print "$0 <predict2Ref.bls> <predinfo> <idmap> <predict seq> <predicted TE end size> <query Id> <output prefix>\n";
	exit(0);
}

my $output=$ARGV[6];
my $len=$ARGV[4]+5;
my %unmapped;
open fin,"<$ARGV[5]" or die $!;
while(<fin>){
	chomp;
	if(/^\s*$/){
		next;
	}
	my @x=split(/\s+/,$_);
	$unmapped{$x[0]}=1;
}
close fin;

my %predInfo;# predicted partner RJM informaiton
open fin,"<$ARGV[1]" or die $!;
while(<fin>){
	chomp;
	if(/^\s*$/){
		next;
	}
	my @x=split(/\t/,$_);
	$predInfo{$x[0]}=$x[1];
}
close fin;

my %shortID;# RJM id map: location --> complete ID
open fin,"<$ARGV[2]" or die $!;
while(<fin>){
	chomp;
	if(/^\s*$/){
		next;
	}
	my @x=split(/\t<-->\t/,$_);
	$shortID{$x[0]}=$x[1];
}
close fin;

my %predict;
open fin, "<$ARGV[3]" or die $!;
my $label;my $seq;
$/=">";
$label=<fin>;
#remove the comment lines above first entry
$/="\n";
while($label=<fin>){
	$label =~ s/^>//;
	$label =~ s/\s*$//;
	$/=">";
	$seq=<fin>;
	$/="\n";
	$seq =~ s/>$//;
	$seq =~ s/\s+//g;
	my @x=split(/\s+/,$label);
	my ($seqId,$start,$stop,$n)=split(/\-\-\-/,$x[0]);
	$predict{"$seqId---$start---$stop"}{$n}=$seq;
}
close fin;

#print "collect information of hits of predicted LTRends+TSDs in references\n";
my %matchPredict;
my %seqPredictHit;
open fin,"<$ARGV[0]" or die $!;
while(<fin>){
	chomp;
	if(/^\s*$/){
		next;
	}
	my @x=split(/\t/,$_);
	if($x[2]==100 && ($x[7]-$x[6]+1)==$len){#the entire predicted TE end + TSD should have exact match
		my ($seqId,$start,$stop,$n)=split(/\-\-\-/,$x[0]);
		$seqPredictHit{$seqId}=1;
		my $rjm="$seqId---$start---$stop";
		my ($predFamID,$predTer)=split(/__/,$predInfo{$rjm});
		
		my $predSeq=$predict{$rjm}{$n};
		
		my $predTsd;
		if($predTer eq "A"){
			$predTsd=substr($predSeq,0,5);
		}else{
			$predTsd=substr($predSeq,-5,5);
		}
		
		my $refOrient="+";
		my $refSeq=$predSeq;
		my $refTsd=$predTsd;
		if($x[8]>$x[9]){
			$refOrient="-";
			$refSeq=rev($predSeq);
			$refTsd=rev($predTsd);
		}
		my ($seqId,$start,$stop,$str,$famTerOrientTsd)=split(/\s+/,$rjm);
		my $firstFam=(split(/,/,$famTerOrientTsd))[0];
		my ($famID,$ter,$orient,$tsd)=split(/__/,$firstFam);
		my $predInRef="$x[1]\t$x[8]\t$x[9]\t$refSeq\t$predFamID\__$predTer\__$refOrient\__$refTsd";
		$matchPredict{$shortID{$rjm}}{$predict{$rjm}{$n}}.="$predInRef\n";
	}
}
close fin;

open fout,">$output.seqPredictNoHit" or die $!;
foreach(sort keys %unmapped){
	if(! exists $seqPredictHit{$_}){
		print fout "$_\n";
	}
}
close fout;

open fout,">$output.predictNotuniqueInRef" or die $!;
open fout1,">$output.predictUniqueInRef" or die $!;
foreach my $rjm(keys %matchPredict){
	my @predSeq=keys %{$matchPredict{$rjm}};
	foreach my $preds(@predSeq){
		my @predInRef=split(/\n/,$matchPredict{$rjm}{$preds});
		foreach (@predInRef){
			if(@predSeq==1 && @predInRef==1){
				print fout1 "$rjm\t$preds\t$_\n";
			}else{
				print fout "$rjm\t$preds\t$_\n";
			}
		}
	}
}
close fout1;
close fout;


sub rev{
	my $x=reverse($_[0]);
	$x=~tr/ATCG/TAGC/;
	$x=~tr/atcg/tagc/;
	return($x);
}
