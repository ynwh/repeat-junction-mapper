use strict;
if(@ARGV<2){
        print "$0 <ele.fa> <ends length>\n";
        exit(0);
}

my $cut=$ARGV[1];


open fin, "<$ARGV[0]" or die "Cannot open $ARGV[0]: $!";
my $label;my $seq;
$/=">";
$label=<fin>;
$/="\n";
while($label=<fin>){
        $label =~ s/^>//;
        $label =~ s/\s*$//;
        $/=">";
        $seq=<fin>;
        $/="\n";
        $seq =~ s/>$//;
	$seq =~ s/\s*//g;
        my $str1=substr($seq,0, $cut);
	my $str2=substr($seq,-1*$cut,$cut);
	if($str1=~/[Nn]{2}/ || $str2=~/[Nn]{2}/){
		next;
	}
	my $lab=(split(/\s+/,$label))[0];
	print ">$lab--A\n$str1\n";
	print ">$lab--B\n$str2\n";
}
close fin;

