use strict;
if(@ARGV<6){
	print "$0 <unique RJM mapping info> <Seq1>  <output prefix> <sizeDiff> <minShare> <ID of queryNoUniqRJM>\n";
	print "<Seq1>: query sequences need to be mapping\n";
	print "<sizeDiff> FLOAT: ratio to control maximum size of mapped region in reference: l_ref = l_query +/- sizeDiff*l_query\n";
	print "<minShare> INT: minimum number of shared markers\n";
	exit(0);
}

my %noUniqMarker;
open fin,"$ARGV[5]" or die $!;
while(<fin>){
	chomp;
	if(/^\s*$/){
		next;
	}
	$noUniqMarker{(split(/\s+/,$_))[0]}=1;
}
close fin;

##Two parameters control mapping quality
my $sizeDiff=1; 
if($ARGV[3]=~/([\d+\.])/){
	$sizeDiff=$ARGV[3];
}
#define l1 = "size the two mapped most distant unique RJMs in query sequence" 
#l2= "size the two mapped most distant unique RJMs in reference sequence"; 
#allowed  l2 = l1 +/- $sizeDiff*l1
#If sizeDiff=1; l2=(0,2*l1)

my $minShare=1;
if($ARGV[4]=~/([\d+])/){
	$minShare=$ARGV[4];
}
#minimum number of colinear RJMs in a query sequence that maps to reference
#its value is the greater value between 2 or 50% of all unique markers.

##one parameter control output files
my $output=$ARGV[2];#output files: (1) region mapped; (2) aligenment for inspection check; (3) colinear mapped region for plot

my %markerQue;
open fin, "<$ARGV[1]" or die "Cannot open $ARGV[1]: $!";
while(<fin>){
	if(/^>(\S+)/){
		$markerQue{$1}="";
	}
}

my %markerRef;
my %nShare;
my %orient;
open fin,"$ARGV[0]" or die $!;
while(<fin>){
	chomp;
	if(/^\s*$/){
		next;
	}
	my @x=split(/\t/,$_);
	$markerQue{$x[0]}.="$x[1],$x[2],";
	$markerRef{$x[0]}{$x[5]}.="$x[7],$x[8],";
	$orient{$x[0]}{$x[5]}.="$x[6],";
	$nShare{$x[0]}{$x[5]}+=1;
}
close fin;

my %orientConflict;
my %orien;
foreach my $q(keys %orient){
	foreach my $r(keys %{$orient{$q}}){
		my %ori;
		foreach(split(/,/,$orient{$q}{$r})){
			$ori{$_}=1;
		}
		$orientConflict{$q}{$r}=int(keys %ori);
		$orien{$q}{$r}=join(",",keys %ori);
	}
}

my %sizeSharedQue;
my %noSharedMarker;
foreach(sort keys %markerQue){
	if($markerQue{$_} eq ""){ #No shared marker
		print "$_ does not contain unique shared markers with referecne. Stop. output for RJM linking \n";
		$noSharedMarker{$_}=1;
	}else{ #Shared marker found
		my @x=sort {$a<=>$b} split(/,/,$markerQue{$_});
		$sizeSharedQue{$_}="$x[0],$x[-1]";
	}
}

my %sizeSharedRef;
foreach my $q(keys %markerRef){
	foreach my $r(keys %{$markerRef{$q}}){
		my @x=sort {$a<=>$b} split(/,/,$markerRef{$q}{$r});
		$sizeSharedRef{$q}{$r}="$x[0],$x[-1]";
	}
}

my %multiLoci;#one continuous query sequence mapped to different referecne sequences. Assembly error
my %fewMarker;#Too few number of shared markers between mapped regions in query and reference 
my %sizeBad;#Inconsistent size in query and reference. Aeembly error
my %orientBad;#shared markers well-mapped, and size is proper, but shared markers showed conflit orientation. They should in the same direction if query and referecne are consistent 
my %allGood;
foreach my $q(keys %sizeSharedQue){
	print "\ncheck sequence $q\n";
	my @mapped=keys %{$sizeSharedRef{$q}};
	print "Check multiple mapping:\n";
	if(@mapped>1){
		print "$q mapped to ".join(";",@mapped).", more than 1 location in reference seqeunces. Stop. Further check assembly error.\n";
		$multiLoci{$q}=join(";",@mapped);
	}else{
		my $r=$mapped[0];
		print "Pass multiple mapping check. $q uniquely mapped to $r\n";
		print "Check number of shared markers (should >= $minShare):\n";
		if($nShare{$q}{$r}<$minShare){
			print "Too few number of shared markers\n";
			$fewMarker{$q}=$r;
		}else{
			print "Pass number of shared markers check. Number shared marker = $nShare{$q}{$r}\n";
			my @pQue=split(/,/,$sizeSharedQue{$q});
			#print "region bounded by shared marker in query: $q\t$pQue[0]\t$pQue[1]\n";
			my $l1=$pQue[1]-$pQue[0]+1;
			#print "size of the region in query: $l1\n";
			
			my @pRef=split(/,/,$sizeSharedRef{$q}{$r});
			#print "sequence bounded by shared marker in reference: $r\t$pRef[0]\t$pRef[1]\n";
			my $l2=$pRef[1]-$pRef[0]+1;
			#print "size of the region in reference: $l2\n";
			print "Check region length (lenInQuery=$l1; lenInRef=$l2) bounded by shared markers (should 0<lenInRef<=lenInQuery+LenInQuery*$sizeDiff):\n";
			if($l2<=$l1+$l1*$sizeDiff){
				print "Pass size check: $q\t$pQue[0]\t$pQue[1]\t$r\t$pRef[0]\t$pRef[1]\t$nShare{$q}{$r}\n";
				print "Check if shared marker in the same orientation in reference:\n";
				if($orientConflict{$q}{$r}>1){
					print "shared markers between $q and $r are not mapped in the same orientation in $r. Stop. Further check assembly error.\n";
					$orientBad{$q}=$r;
				}else{
					print "WELL MAPPED: $q\t$pQue[0]\t$pQue[1]\t$r\t$pRef[0]\t$pRef[1]\t$nShare{$q}{$r}\t$orien{$q}{$r}\n";
					$allGood{$q}=$r;
				}
			}else{
				print "sizeBad: $q\t$pQue[0]\t$pQue[1]\t$r\t$pRef[0]\t$pRef[1]. Stop. Further check assembly error.\n";
				$sizeBad{$q}=$r; #
			}
		}
	}
}

open fout,">$output.wellMapped" or die $!;
foreach my $q(sort keys %allGood){
	my $r=$allGood{$q};
	my @pQue=split(/,/,$sizeSharedQue{$q});
	my @pRef=split(/,/,$sizeSharedRef{$q}{$r});
	print fout "$q\t$pQue[0]\t$pQue[1]\t$r\t$pRef[0]\t$pRef[1]\t$nShare{$q}{$r}\t$orien{$q}{$r}\n";
}
close fout;

open fout,">$output.markerOrentationInconsistent" or die $!;
foreach my $q(sort keys %orientBad){
	my $r=$orientBad{$q};
	my @pQue=split(/,/,$sizeSharedQue{$q});
        my @pRef=split(/,/,$sizeSharedRef{$q}{$r});
        print fout "$q\t$pQue[0]\t$pQue[1]\t$r\t$pRef[0]\t$pRef[1]\t$nShare{$q}{$r}\t$orien{$q}{$r}\n";
}
close fout;

open fout,">$output.nonLocalMapped" or die $!;
foreach my $q(sort keys %sizeBad){
	my $r=$sizeBad{$q};
	print fout "$q\t$r\tSameSequence\ttooLargeSizeBetweenMarkers\n";
}

foreach my $q(sort keys %multiLoci){
	my $r=$multiLoci{$q};
	print fout "$q\t$r\tMultipleSequence\tMarkersNotInTheSameSequence\n";
}
close fout;

open fout,">$output.unmapped" or die $!;
foreach my $q(sort keys %fewMarker){
	my $r=$fewMarker{$q};
	print fout "$q\t$r\t$nShare{$q}{$r}\n";
}
foreach my $q(sort keys %noSharedMarker){
	if(!exists $noUniqMarker{$q}){
		print fout "$q\tNA\t0\n";
	}
}
close fout;

