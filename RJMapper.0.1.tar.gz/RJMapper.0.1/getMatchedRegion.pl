use strict;
if(@ARGV<3){
	print "$0 <bls> <query> <reference>\n";
	exit(0);
}

my @query;my $qid;my $qlen;
open fin, "<$ARGV[1]" or die $!;
my $label;my $seq;my %queryLen;
$/=">";
$label=<fin>;
$/="\n";
while($label=<fin>){
        $label =~ s/^>//;
        $label =~ s/\s*$//;
        $/=">";
        $seq=<fin>;
        $/="\n";
        $seq =~ s/>$//;
        $seq =~ s/\s+//g;
	$qid=(split(/\s+/,$label))[0];
	$qlen=length($seq);
        @query=split(//,0 x $qlen);
	last;
}
close fin;

my @ref;my $rid;my $rlen;
open fin, "<$ARGV[2]" or die $!;
$/=">";
$label=<fin>;
$/="\n";
while($label=<fin>){
        $label =~ s/^>//;
        $label =~ s/\s*$//;
        $/=">";
        $seq=<fin>;
        $/="\n";
        $seq =~ s/>$//;
        $seq =~ s/\s+//g;
	$rid=(split(/\s+/,$label))[0];
	$rlen=length($seq);
        @ref=split(//,0 x $rlen);
	last;
}
close fin;


open fin,"<$ARGV[0]" or die $!;
while(<fin>){
	chomp;
	if(/^\s*$/){
		next;
	}
	my @x=split(/\t/,$_);
	if($x[0] ne $qid || $x[1] ne $rid){
		next;
	}
	my @y=sort {$a<=>$b} ($x[8],$x[9]);
	foreach(my $i=$x[6]-1;$i<$x[7];++$i){
		$query[$i]+=1;
	}
	foreach(my $i=$y[0]-1;$i<$y[1];++$i){
		$ref[$i]+=1;
	}
}
close fin;

my $queryStart=0;
my $queryStop=$qlen;
my $queryMatch=0;
foreach(my $i=0;$i<$qlen;++$i){
	++$queryStart;
	if($query[$i]>0){
		last;
	}
}
foreach(my $i=$qlen-1;$i>=0;--$i){
	if($query[$i]>0){
		last;
	}
	--$queryStop;
}
foreach(my $i=0;$i<$qlen;++$i){
        if($query[$i]>0){
                $queryMatch+=1;
        }
}

my $queryPerc=int(0.5+1000*$queryMatch/$qlen)/1000;

my $refStart=0;
my $refStop=$rlen;
my $refMatch=0;
foreach(my $i=0;$i<$rlen;++$i){
	++$refStart;
	if($ref[$i]>0){
		last;
	}
}
foreach(my $i=$rlen-1;$i>=0;--$i){
	if($ref[$i]>0){
		last;
	}
	--$refStop;
}
foreach(my $i=$refStart-1;$i<$refStop;++$i){
        if($ref[$i]>0){
                $refMatch+=1;
        }
}

my $refPerc=int(0.5+1000*$refMatch/($refStop-$refStart+1))/1000;

print "$qid\t$qlen\t$queryStart\t$queryStop\t$queryMatch\t$queryPerc\t$rid\t$rlen\t$refStart\t$refStop\t$refMatch\t$refPerc\n";
