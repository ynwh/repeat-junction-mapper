use strict;
use File::Basename;
use Getopt::Std;
getopts("b:i:j:t:o:l:c:s:B:E:h:p:S:n:r:");
use vars qw($opt_b $opt_i $opt_j $opt_t $opt_o $opt_l $opt_c $opt_s $opt_B $opt_E $opt_h $opt_p $opt_S $opt_n $opt_r);
my $scripts=defined $opt_b ? $opt_b : "./";
my $queryFile=defined $opt_i ? $opt_i : "";
my $refFile=defined $opt_j ?$opt_j : "";
my $teFile=defined $opt_t ? $opt_t : "";
my $outPre=defined $opt_o ? $opt_o : "";
my $sizeEnd=defined $opt_s ? $opt_s : 50;
my $cpuNum=defined $opt_c ? $opt_c : 4;
my $sizeRJM=defined $opt_l ? $opt_l : 50;
my $blast=defined $opt_B ? $opt_B : "blastall";
my $easyFig=defined $opt_E ? $opt_E : "python Easyfig_CL_2.1.py";
my $help=defined $opt_h ? $opt_h : "";
my $step=defined $opt_p ? $opt_p : 123;
my $minSim=defined $opt_S ? $opt_S : 1;
my $minSuRJM=defined $opt_n ? $opt_n : "1";
my $ratio=defined $opt_r ? $opt_r : "2";

if($step==1){#run RJM Detection and RJM Direct Mapping
	print "Please Type perl RJMapper_INSTALL_DIR/RJMDetection.pl for further information\n";
	exit(0);
}

if($step==123){#run all 3 modules
	usage123() if((!$queryFile)||(!$refFile)||(!$teFile)||(!$outPre)||($help));
	print "begin to run RJMapper\n";
	my $outRJMDetection="$outPre.RJMDetection";
	if(-s $queryFile && -s $teFile){
		print "run RJM Detection module\n";
		my $teFormated=0;
		if(-e "$teFile.nhr"){
			$teFormated=$teFile;
		}
		my $queryFormated=0;
		if(-e "$queryFile.nhr"){
			$queryFormated=$queryFile;
		}
		print "perl $scripts/RJMDetection.pl -b $scripts -i $queryFile -F $queryFormated -t $teFile -f $teFormated -o $outRJMDetection -l $sizeRJM -s $sizeEnd -c $cpuNum -S $minSim -B $blast\n";
		system "perl $scripts/RJMDetection.pl -b $scripts -i $queryFile -F $queryFormated -t $teFile -f $teFormated -o $outRJMDetection -l $sizeRJM -s $sizeEnd -c $cpuNum -S $minSim -B $blast";
		print "Done RJM detection module\n";
		
		my $uniqRJMQuery="$outRJMDetection.uniqRJM.inQuerySet";
		my $uniqRJMQuerySeq="$outRJMDetection.uniqRJM.inQuerySet.seq";
		my $noUniqMarker="$outRJMDetection.queryNoUniqRJM";
		my $outRJMDirectMapping="$outPre.RJMDirectMapping";
		if(-s $uniqRJMQuery){
			print "run RJM Direct Mapping module\n";
			my $refFormated=0;
			if(-e "$queryFile.nhr"){
				$refFormated=$refFile;
			}
			print "perl $scripts/RJMDirectMapping.pl -b $scripts -i $queryFile -j $refFile -F $refFormated -u $uniqRJMQuery -m $uniqRJMQuerySeq -E \"$easyFig\" -o $outRJMDirectMapping -x $noUniqMarker -l $sizeRJM -S $minSim -n $ minSuRJM -r $ratio -c $cpuNum -B $blast\n";
			system "perl $scripts/RJMDirectMapping.pl -b $scripts -i $queryFile -j $refFile -F $refFormated -u $uniqRJMQuery -m $uniqRJMQuerySeq -E \"$easyFig\" -o $outRJMDirectMapping -x $noUniqMarker -l $sizeRJM -S $minSim -n $ minSuRJM -r $ratio -c $cpuNum -B $blast";
			print "Done RJM Direct Mapping module\n";
			
			my $outPartnerRJMSearching="$outPre.PartnerRJMSearching";
			my $unmappedID="$outRJMDirectMapping.unmapped";
			my $teEnd="$outRJMDetection.TEends";
			if(-s $unmappedID){
				print "run Partner RJM Searching module\n";
				print "perl $scripts/SearchingForPartnerRJT.pl -b $scripts -I $unmappedID -j $refFile -F $refFormated -u $uniqRJMQuery -T $teEnd -o $outPartnerRJMSearching -s $sizeEnd -c $cpuNum -B $blast\n";
				system "perl $scripts/SearchingForPartnerRJT.pl -b $scripts -I $unmappedID -j $refFile -F $refFormated -u $uniqRJMQuery -T $teEnd -o $outPartnerRJMSearching -s $sizeEnd -c $cpuNum -B $blast";
				print "Done Partner RJM Searching module\n";
			}else{
				print "$unmappedID. File size = 0. No query sequecne needs to be anchored. Stop at the end of RJM Direct Mapping module.\n";
			}
		}else{
			print "$uniqRJMQuery. File size = 0. No sequence contain unique RJMs. Stop at the end of RJM Detection module.\n";
		}
	}else{
		print "query file and/or TE database does not have sequences. Stop before running RJMapper\n";
	}
	if(-e "formatdb.log"){
		unlink "formatdb.log";
	}
	if(-e "error.log"){
		unlink "error.log";
	}
#	system "rm -rf PartnerRJMSearching RJMDetection RJMDirectMapping";
	print "Done RJMapper\n";
}

if($step==12){#run RJM Detection and RJM Direct Mapping
	usage12() if((!$queryFile)||(!$refFile)||(!$teFile)||(!$outPre)||($help));
}

sub usage123{
	 print "Usage: program <options>\n";
	 print "Parameter used by all modules\n";
	 print "-o     STRING     Output prefix [required]\n";
	 print "-b     STRING     Dir where the RJMapper program installed\n";
	 print "                  [default ./]\n";
	 print "-B     STRING     BLAST commend path [default blastall]\n";
	 print "-c     INT        CPU number when compute BLAST [default 4]\n";
	 print "-h     STRING     Show this help message\n";
	 
	 print "\nParameters used by module RJM Detection and RJM Direct Mapping\n";
	 print "-i     STRING     Query set file path [required]\n";
	 print "-l     EVEN INT   Size of RJM [default 50]\n";
	 print "-S     FLOAT      Minimum similarity value when counting copy\n";
	 print "                  number of RJM [default 1.0]\n";
	 
	 print "\nParameters used by module RJM Detection and Partner RJM searching\n";
	 print "-t     STRING     LTR element database file path [required]\n";
	 print "-s     INT        Size of predicted LTR end [default 50]\n";
	 
	 print "\nParamters used by module RJM Direct Mapping and Partner RJM searching\n";
	 print "-j     STRING     Reference set file path [required]\n";
	 
	 print "\nParamters only used by RJM Direct Mapping module\n";
	 print "-n     INT        Minimum number of share unique RJMs (suRJMs)\n";
	 print "                  [default 1]\n";
	 print "-r     INT        Mapping d/query d. d=distance between most\n";
	 print "                  left and right suRJMs [default 2]\n";
	 print "-E     STRING     Program easyFig commend path\n";
	 print "                  [default python Easyfig_CL_2.1.py]\n";
	 	 
	 print "\nParameter used by RJMapper\n";
	 print "-p     STRING     step code.\n";
	 print "                  123: program walks through the 3 modules\n";
	 print "                  12 : program walks through module 1 and 2\n";
	 print "                  1  : program walks through module 1 only\n";
	 print "                  [Default 123]\n";
	 
	 print "\nPlease confirm the three parameters: -b, -B or -E (if -p contain code 2)\n";
	 print "before running RJMapper\n";
	 exit(0);	
}

sub usage12{
	 print "Usage: program <options>\n";
	 print "Parameter used by module RJM Detection and RJM Direct Mapping\n";
	 print "-o     STRING     Output prefix [required]\n";
	 print "-b     STRING     Dir where the RJMapper program installed\n";
	 print "                  [default ./]\n";
	 print "-B     STRING     BLAST commend path [default blastall]\n";
	 print "-c     INT        CPU number when compute BLAST [default 4]\n";
	 print "-h     STRING     Show this help message\n";
	 print "-i     STRING     Query set file path [required]\n";
	 print "-l     EVEN INT   Size of RJM [default 50]\n";
	 print "-S     FLOAT      Minimum similarity value when counting copy\n";
	 print "                  number of RJM [default 1.0]\n";
	 
	 print "\nParameters used by module RJM Detection\n";
	 print "-t     STRING     LTR element database file path [required]\n";
	 
	 print "\nParameters used by module RJM Direct Mapping\n";
	 print "-j     STRING     Reference set file path [required]\n";
	 print "-n     INT        Minimum number of share unique RJMs (suRJMs)\n";
	 print "                  [default 1]\n";
	 print "-r     INT        Mapping d/query d. d=distance between most\n";
	 print "                  left and right suRJMs [default 2]\n";
	 print "-E     STRING     Program easyFig commend path\n";
	 print "                  [default python Easyfig_CL_2.1.py]\n";
	 
	 print "\nParameter used by RJMapper\n";
	 print "-p     STRING     step code.\n";
	 print "                  123: program walks through the 3 modules\n";
	 print "                  12 : program walks through module 1 and 2\n";
	 print "                  1  : program walks through module 1 only\n";
	 print "                  [Default 123]\n";
	 
	 print "\nPlease confirm the three parameters: -b, -B or -E (if -p contain code 2)\n";
	 print "before running RJMapper\n";
	 print "\nEXAMPLE: perl ../../RJMapper/RJMapper.pl -i ../25unanchored-RJMSize50/25unanchored.shortID.fasta -j ../../AGPv3.fa -t ../../maizetedb.20140611.LTR.examplar -o 25unanchored-RJMSize140 -b ../../RJMapper/ -c 1 -l 140 -E \"python27 ~/opt/Easyfig_2.1/Easyfig_CL_2.1.py\"";
         exit(0);

}
