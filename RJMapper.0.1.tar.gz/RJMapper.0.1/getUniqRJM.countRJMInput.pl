use strict;
if(@ARGV<3){
	print "$0 <countRJM output> <RJM> <uniq RJM sequence file>\n";
	exit(0);
}

my %uniq;
open fin,"<$ARGV[0]" or die $!;
while(<fin>){
	if(/^\s*$/){
		next;
	}
	my ($id,$count)=split(/\s+/,$_);
	if($count==1){
		$uniq{$id}=1;
	}
}
close fin;  

open fout, ">$ARGV[2]" or die $!;
open fin,"<$ARGV[1]" or die $!;
while(<fin>){
	if(/^\s*$/){
		next;
	}
	my @x=split(/\s+/,$_);
	if(exists $uniq{"$x[0]---$x[1]---$x[2]"}){
		print $_;
		print fout ">$x[0]---$x[1]---$x[2]\n$x[3]\n";
	}
}
close fin;
close fout;
