use strict;
use File::Basename;
use bytes;

if(@ARGV<2){
	print "$0 <RJM blast result> <rjm>\n";
	exit(0);
}

#my $f=basename($0);
#my $logfile="log.$f";
#$logfile=~s/\.pl$//;
#open logs, ">$logfile" or die $!;
#print logs "Read in RJM\n";
my %rjm;my %id2marker;
open fin,"<$ARGV[1]" or die $!;
while(<fin>){
	if(/^\s*$/){
		next;
	}
	chomp;
	my @x=split(/\t/,$_);
	my $marker=join(" ",sort($x[3],rev($x[3])));
	$rjm{$marker}.="$_\n"; # one marker may occur at multiple positions
	#it is allowed since RJMs are discoverd in reads
	$id2marker{"$x[0]---$x[1]---$x[2]"}=$marker;
}
close fin;


#print logs "Read in BLAST result ... ";
my %marker2pos;
open fin,"<$ARGV[0]" or die $!;
while(<fin>){
	my @x=split(/\t/,$_);
	my $marker=$id2marker{$x[0]};
	my $orient="+";
	if($x[8]>$x[9]){
		$orient="-";
	}
	my @y=sort {$a<=>$b} ($x[8],$x[9]);	

	$marker2pos{$marker}{"$x[1],$orient,$y[0],$y[1]"}=1;
	
}
close fin;
#print logs "Finish reading BLAST\n";

my %markerInfo;
my $nuniq=0;
my $nmulti=0;
foreach my $marker(keys %marker2pos){	
	my @x=keys %{$marker2pos{$marker}};
	my $n=@x;
	#print logs ">$marker occurs $n times:\n";
	#print logs "$marker\t$n\t".join(";",sort @x)."\n";
	#print logs $rjm{$marker};
	if($n==1){
		++$nuniq;
		$rjm{$marker}=~s/\s*$//;
		$x[0]=~s/,/\t/g;
		print "$rjm{$marker}\t$x[0]\n";
		
	}else{
		++$nmulti;
	}
	#print logs "\n";
}

#print logs "\nNumber of Uniq marker=$nuniq\n";
#print logs "Number of non-uniq marker=$nmulti\n";
#close logs;


sub rev{
        my $x=reverse($_[0]);
        $x=~tr/ATCG/TAGC/;
        $x=~tr/atcg/tagc/;
        return($x);
}

