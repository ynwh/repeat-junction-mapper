#reads mapping info
#cut sequence: region sut on reference = double size of query
#generate blastn
#generate GenBank annotation file
#draw figure with easyFig

use strict;
if(@ARGV<7){
	print "$0 <uniqRJMMap> <directMap Info> <Seq1> <Seq2> <alignment output dir> <easyFig commandline path> <getMatchedRegion script dir>\n";
	print "Example of <easyFig commandline path>: python27 ~/opt/Easyfig_2.1/Easyfig_CL_2.1.py\n";
	exit(0);
}

my $workdir=$ARGV[4];
my $EasyFig="$ARGV[5] -blast_height 500 -blast_col_inv 0 200 0 0 100 0 -f1 T -f2 10000 -min_length 5000 -i 95 -f misc_feature 0 0 127 pointer -f unsure 0 0 0 rect";
my $getMatchedRegion=" $ARGV[6]/getMatchedRegion.pl";

if(-e "$workdir"){
#       print "$workdir exists. clean it.\n";
        system "rm -rf $workdir/*";
}else{
#       print "$workdir does not exists. build it.\n";
        mkdir "$workdir", 0755 or warn "cannot create $workdir directory:$!";
}


my %query;
my %queryNs;
open fin, "<$ARGV[2]" or die "Cannot open $ARGV[1]: $!";
my $label;my $str;
$/=">";
$label=<fin>;
$/="\n"; 
while($label=<fin>){
        $label =~ s/^>//;
        $label =~ s/\s*$//;               
        $/=">";
        $str=<fin>;  
        $/="\n";
        $str =~ s/>$//;
        $str =~ s/\s+//g;
        my $lab=( split(/\s+/,$label) )[0];
        $query{$lab}=$str;
	while($str=~/([Nn]+)/g){
		my $len=length($1);
		my $end=pos($str);
		my $start=$end-$len+1;
		$queryNs{$lab}.="$start,$end;";
	}

}
close fin;

my %ref;
open fin, "<$ARGV[3]" or die "Cannot open $ARGV[2]: $!";
$/=">";
$label=<fin>;
$/="\n"; 
while($label=<fin>){
        $label =~ s/^>//;
        $label =~ s/\s*$//;               
        $/=">";
        $str=<fin>;  
        $/="\n";
        $str =~ s/>$//;
        $str =~ s/\s+//g;
        my $lab=( split(/\s+/,$label) )[0];
        $ref{$lab}=$str;
	
}
close fin;

my %markerQue;
my %markerRef;
open fin,"<$ARGV[0]" or die $!;
while(<fin>){
        chomp;
        my @x=split(/\t/,$_);
        $markerQue{$x[0]}.="$x[1],$x[2],+;";
        $markerRef{"$x[0] $x[5]"}.="$x[7],$x[8],$x[6];";
}
close fin;

my %markerCutRef;
my %cutRefNs;
my %cutRef;
open fin,"<$ARGV[1]" or die $!; 
foreach(<fin>){
	if(/^\s*$/){
		next;
	}
	my @x=split(/\s+/,$_);
	my $queryId=$x[0];
	my $l=length($query{$x[0]});
	my $refId=$x[3];
	my $l2=$x[5]-$x[4]+1;
	my $ext=0;
	my $d=2*$l-$l2;
	if($d>0){
		$ext=int($d/2);	
	}else{
		$d=0;
	}
	my $cut="";
	my $cutRefId="$queryId $refId";
	if($x[4]-$ext>0){
		$cut=substr($ref{$refId},$x[4]-1-$ext,$l2+$d);
#		print "cutRef: query=$queryId; l_query=$l; markerPos=$x[4],$x[5]; start=".($x[4]-$ext)." stop=".($x[4]-$ext+$l2+$d-1)."; length=".length($cutRef).",".($l2+$d)."\n";
		foreach(split(/;/,$markerRef{"$queryId $refId"})){
			my ($start,$stop,$chain)=split(/,/,$_);
			$markerCutRef{$cutRefId}.=($start-($x[4]-1-$ext)).",".($stop-($x[4]-1-$ext)).",".$chain.";";
		}
	}else{
		$cut=substr($ref{$refId},0,$l2+$d);
#		print "cutRef: query=$queryId; l_query=$l; markerPos=$x[4],$x[5]; start=1 stop=".($l2+$d)."; length=".length($cutRef).",".($l2+$d)."\n";
		$markerCutRef{$cutRefId}=$markerRef{$cutRefId};
	}
#	print "marker position in ref: $markerRef{$cutRefId}\n";
#	print "marker posiiton in cut ref: $markerCutRef{$cutRefId}\n";
	while($cut=~/([Nn]+)/g){
		my $len=length($1);
		my $end=pos($cut);
		my $start=$end-$len+1;
		$cutRefNs{$cutRefId}.="$start,$end;";
	}
	$cutRef{$cutRefId}=$cut;
}
close fin;

foreach my $q(sort keys %markerCutRef){
	my ($queryId,$refId)=split(" ",$q);
	my $cutRefId="$queryId $refId";
		
	my $outputQueryId=$queryId;
	$outputQueryId=~s/[\W]/__/g;
	my $outputRefId=$refId;
	$outputRefId=~s/[\W]/__/g;
	my $output="$workdir/$outputQueryId--$outputRefId";
	mkdir "$output", 0755 or warn "cannot create $output directory:$!";
	open fout,">$output/$outputQueryId.fa" or die $!;
	print fout ">$queryId\n$query{$queryId}\n";
	close fout;
	
	open fout,">$output/$outputQueryId.gbk" or die $!;
	print fout "LOCUS    $queryId    ".length($query{$queryId})." bp    DNA    XXX    XX-XX-XXXX\n";
	print fout "FEATURES             Location/Qualifiers\n";
	print fout "     source          1..".length($query{$queryId})."\n";
	foreach(split(/;/,$queryNs{$queryId})){
		my ($start,$stop)=split(/,/,$_);
		print fout "     unsure          $start..$stop\n";
	}
	foreach(split(/;/,$markerQue{$queryId})){
		my ($start,$stop,$chain)=split(/,/,$_);
		print fout "     misc_feature    $start..$stop\n";
	}
	print fout "ORIGIN\n";
	print fout FormatSequence(\$query{$queryId},60);
	print fout "\\"."\\"."\n";
	close fout;
	
	open fout,">$output/$outputRefId.fa" or die $!;
	print fout ">$refId\n$cutRef{$cutRefId}\n";
	close fout;

	open fout,">$output/$outputRefId.gbk" or die $!;
	print fout "LOCUS    $refId    ".length($cutRef{$cutRefId})." bp    DNA    XXX    XX-XX-XXXX\n";
	print fout "FEATURES             Location/Qualifiers\n";
	print fout "     source          1..".length($cutRef{$cutRefId})."\n";
	foreach(split(/;/,$cutRefNs{$cutRefId})){
		my ($start,$stop)=split(/,/,$_);
		print fout "     unsure          $start..$stop\n";
	}
	foreach(split(/;/,$markerCutRef{$cutRefId})){
		my ($start,$stop,$chain)=split(/,/,$_);
		if($chain eq "+"){
			print fout "     misc_feature    $start..$stop\n";
		}else{
			print fout "     misc_feature    complement($start..$stop)\n";
		}
	}
	print fout "ORIGIN\n";
	print fout FormatSequence(\$cutRef{$cutRefId},60);
	print fout "\\"."\\"."\n";
	close fout;
	
	system "$EasyFig -o $output/$outputQueryId--$outputRefId.bmp $output/$outputQueryId.gbk $output/$outputRefId.gbk >/dev/null 2>&1";
	#get matched region information
	system "formatdb -i $output/$outputRefId.fa -pF";
	system "blastall -p blastn -e 1e-10 -d $output/$outputRefId.fa -i $output/$outputQueryId.fa -m 8 -o $output/$outputQueryId--$outputRefId.bls";
	system "$getMatchedRegion $output/$outputQueryId--$outputRefId.bls $output/$outputQueryId.fa $output/$outputRefId.fa >$output/$outputQueryId--$outputRefId.getMatchedRegion";
	system "rm $output/$outputRefId.fa.n* $output/$outputQueryId.fa $output/$outputRefId.fa $output/$outputQueryId--$outputRefId.bls";
}

sub FormatSequence
{
    my($seq,$colume)=@_;
 
    my $len=length($$seq);
    my $out;
    my $i;
    for($i=0;$i<($len);$i+=$colume)
    {
         my $st=$i+1;
         my $str=substr($$seq,$i,$colume);
         $str=~s/(\w{10})/$1 /g;
         $out.=sprintf("%15s %s\n",$st,$str);
    }
    return $out;
}

