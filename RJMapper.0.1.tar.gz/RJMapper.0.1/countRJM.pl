use strict;
use File::Basename;
if(@ARGV<2){
	print "$0 <filtered blast m8> <output percentage file>\n";
	exit(0);
}

my $output=$ARGV[1];

my %count;
open fin,"<$ARGV[0]" or die $!;
while(<fin>){
	if(/^\s*$/){
		next;
	}
	my @x=split(/\t/,$_);
	$count{$x[0]}+=1;
}
close fin;

#my $f=basename($0);
#my $logfile="log.$output.$f";
#$logfile=~s/\.pl$//;

#open logs, ">$logfile" or die $!;
my $nuniq=0;
my $nmulti=0;
my $nuniqType=0;
my $nmultiType=0;
foreach(sort keys %count){
	print "$_\t$count{$_}\n";
	if($count{$_}>1){
		$nmultiType+=1;
		$nmulti+=$count{$_};
	}elsif($count{$_}==1){
		$nuniqType+=1;
		$nuniq+=$count{$_};
	}
}
my $all=$nuniq+$nmulti;
my $allType=$nuniqType+$nmultiType;
my $percUnique=int(0.5+1000*($nuniq/$all))/1000;
my $percMulti=int(0.5+1000*($nmulti/$all))/1000;
#print logs "Parameter\tAllRJM\tUnique\tPerc_Unique\tMulti\tPerc_Multi\n";
open fout, ">$output" or die $!;
print fout "$output\t$allType\t$all\t$nuniqType\t$nuniq\t$percUnique\t$nmultiType\t$nmulti\t$percMulti\n";
close fout;
