use strict;
use File::Basename;

#filter blast results: if query is 5'ends, the 1st base should be matched
#if query is 3' ends, the last base should be matched
#match length >= lcut% of query length
#3 parameters should be set in the scripts
#$tsdSize, $exlen, $ex3Len;
if(@ARGV<5){
	print "$0 <bls8> <match length cutoff (0,1)> <bls query sequences> <bls db genomic sequences> <RJM radius>\n";
	print "<bls query sequence>: sequence ID should be XXX--A or XXX--B, with A and B represent two ends of a TE\n";
	print "<max RJM size>: radium that extract sequence from genomic sequence.\n";
	print "OUTPUT:\nTEEndID\thitSeqID\tstrand\tstartH\tstopH\tcandidateTSD\thit+TSD\textOut(or RJM centered at TE terminal)\textIn\n";
	print "hitSeq: sequence that hit TE ends. Hit represent the subregion that hit the TE ends\n";
	print "startH: start coordinate (count from 1) in hitSeq\n";
	print "stopH: stop coordinate (count from 1) in hitSeq\n";
	print "candidateTSD: TSD candiate constructed by extract substring flanking sequence of end of hit, orientation on hits\n";
	print "hit+TSD: subregion directly extracted from hit sequence\n";
	print "extOut (RJM): flanking of hits terminals. Length is set in the script (default 30).\n";
	print "extIn: hit extends toward TE internal region. Length is set in the script (default 50).\n";
	exit(0);
}

my $lcut=$ARGV[1];
my $tsdSize=5; 
## will be used in $ex1 and $ex2
my $exlen=30;
if($ARGV[4] =~ /^\d+$/){
	$exlen=$ARGV[4];
}
## extend inside the TE, use to confirm the ends are really come from TE
my $ex3Len=50;

#my $f=basename($0);
#my $logfile="log.$f";
#$logfile=~s/\.pl$//;
#open fout, ">$logfile" or die $!;

my %lenQ;
my %end;
open fin, "<$ARGV[2]" or die "Cannot open $ARGV[2]: $!";
my $label;my $seq;
$/=">";
$label=<fin>;
$/="\n"; 
while($label=<fin>){
        $label =~ s/^>//;
        $label =~ s/\s*$//;
        $/=">";
        $seq=<fin>;  
        $/="\n";
        $seq =~ s/>$//;
        $seq =~ s/\s+//g;
        my @lab=split(/\s+/,$label);
        $lenQ{$lab[0]}=length($seq);
	$end{$lab[0]}=$seq;
}
close fin;

my %genomic;
open fin, "<$ARGV[3]" or die "Cannot open $ARGV[3]: $!";
$/=">";
$label=<fin>;
$/="\n"; 
while($label=<fin>){
        $label =~ s/^>//;
        $label =~ s/\s*$//;
        $/=">";
        $seq=<fin>;  
        $/="\n";
        $seq =~ s/>$//;
        $seq =~ s/\s+//g;
        my @lab=split(/\s+/,$label);
        $genomic{$lab[0]}=$seq;
}
close fin;

open fin,"<$ARGV[0]" or die $!;
while(my $line=<fin>){
	if($line=~/^\s*$/){next;}
	chomp($line);
	my @x=split(/\t/,$line);
	my $lenq=$lenQ{$x[0]};
	my $hit=$genomic{$x[1]};
	my $lenh=length($hit);
	my $tsd="";
	my $ex1="";
	my $ex2="";
	my $ex3="";
	my $chain="";
	my $otherendID=$x[0];
	my $stat=1;
	if($x[8] < $exlen || $x[8]+$exlen > $lenh || $x[9] < $exlen || $x[9]+$exlen > $lenh ){
		#print fout "CloseToBoundary: hit length=$lenh $line\n";
		$stat=0;
	}else{
	if($x[7]-$x[6]+1>=$lcut*$lenq){
		if( ($x[0]=~/--A/ && $x[6]==1) ){
                        $otherendID=~s/--A/--B/;
			if($x[8]<$x[9]){ # + strand
				$chain="+";
				$tsd=substr($hit,$x[8]-1-$tsdSize,$tsdSize); #possible TSD. need further validation by get the other ends
				$ex1=substr($hit,$x[8]-1-$tsdSize,$tsdSize+$lenq);
				$ex2=substr($hit,$x[8]-1-$exlen,2*$exlen);
				$ex3=substr($hit,$x[8]-1,$ex3Len);
			}elsif($x[8]>$x[9]){ # - strand
				$chain="-";
				$tsd=substr($hit,$x[8],$tsdSize);
				$ex1=substr($hit,$x[8]-$lenq,$lenq+$tsdSize);
				$ex2=substr($hit,$x[8]-$exlen,2*$exlen);
				$ex3=substr($hit,$x[8]-$ex3Len,$ex3Len);
			}else{
				#print fout "ZeroSizeMatch: $line\n";
				$stat=0;
			}
		}elsif( ($x[0]=~/--B/ && $x[7]==$lenq) ){
			$otherendID=~s/--B/--A/;
			if($x[8]<$x[9]){ # + strand
				$chain="+";
				$tsd=substr($hit,$x[9],$tsdSize);
				$ex1=substr($hit,$x[9]-$lenq,$tsdSize+$lenq);
				$ex2=substr($hit,$x[9]-$exlen,2*$exlen);
				$ex3=substr($hit,$x[9]-$ex3Len,$ex3Len);
			}elsif($x[8]>$x[9]){ # - strand
				$chain="-";
				$tsd=substr($hit,$x[9]-1-$tsdSize,$tsdSize);
				$ex1=substr($hit,$x[9]-1-$tsdSize,$tsdSize+$lenq);
				$ex2=substr($hit,$x[9]-1-$exlen,2*$exlen);
				$ex3=substr($hit,$x[9]-1,$ex3Len);
			}else{
                                #print fout "ZeroSizeMatch: $line\n";
                                $stat=0;
                        }
		}else{
			#print fout "TerminalNotMatch: $line\n";
			$stat=0;
		}	
	}else{
		#print fout "ShortMatch: $line\n";
		$stat=0;
	}
	}
	if($stat == 0){
		next;
	}else{
		if($chain eq "+"){
			print "$x[0]\t$x[1]\t$chain\t$x[8]\t$x[9]\t$tsd\t$ex1\t$ex2\t$ex3\n";
		}else{
			print "$x[0]\t$x[1]\t$chain\t$x[9]\t$x[8]\t$tsd\t$ex1\t$ex2\t$ex3\n";
		}
	}	
}
close fin;
#close fout;

sub rev{
	my $x=reverse($_[0]);
        $x=~tr/ATCG/TAGC/;
	$x=~tr/atcg/tagc/;
	return($x);
}
