use strict;
use File::Basename;
use Getopt::Std;
getopts("i:t:l:o:c:S:h:b:B:F:f:s:x:");
use vars qw($opt_i $opt_t $opt_l $opt_o $opt_c $opt_S $opt_h $opt_b $opt_B $opt_F $opt_f $opt_s $opt_x);
my $queryFile=defined $opt_i ? $opt_i : "";
my $teFile=defined $opt_t ? $opt_t : "";
my $outPre=defined $opt_o ? $opt_o : "";
my $scripts=defined $opt_b ? $opt_b : "";
my $sizeRJM=defined $opt_l ? $opt_l : 50;
my $sizeEnd=defined $opt_s ? $opt_s : 50;
my $cpuNum=defined $opt_c ? $opt_c : 4;
my $minSim=defined $opt_S ? $opt_S : 1;
my $blast=defined $opt_B ? $opt_B : "blastall";
my $help=defined $opt_h ? $opt_h : "";
my $qformated=defined $opt_F ? $opt_F : 0;
my $tformated=defined $opt_f ? $opt_f : 0;
my $ateFile=defined $opt_x ? $opt_x : "";

usage() if((!$scripts)||(!$queryFile)||(!$teFile)||(!$outPre)||($help));

sub usage{
	print "Usage: program <options>\n";
	print "-b     STRING     Dir that the RJMapper program installed\n";
	print "                  [required]\n";
	print "-i     STRING     Query set file path [required]\n";
	print "-t     STRING     LTR element database file path [required]\n";
	print "-o     STRING     Output prefix [required]\n";
	print "-l     EVEN INT   Size of RJM [default 50]\n";
	print "-s     INT        Size of LTR end [default 50]\n";
	print "-c     INT        CPU number when compute BLAST [default 4]\n";
	print "-S     FLOAT      Minimum similarity value when counting copy\n";
	print "                  number of RJM [default 1.0]\n";
	print "-B     STRING     BLAST commend path [default blastall]\n";
	print "-F     0/STRING   Path to blast database of query set. If 0,\n";
	print "                  not formated. If STRING, path to the database\n";
	print "                  [default 0]\n";
	print "-f     0/STRING   Path to blast database of TE file. If 0,\n";
	print "                  not formated. If STRING, path to the database\n";
	print "                  [default 0]\n";
	print "-x     STRING     An alternative TE file. If set, the filter\n";
        print "                  of RJs that located in TEs will be performed\n";
        print "                  using this file as reference data base.\n";
        print "                  [default value of -t parameter]\n";
	print "-h     STRING     Show this help message\n";
	exit(0);
}

my $workdir="RJMDetection";

print "build working directory: $workdir\n";
if(-e "$workdir"){
        print "$workdir exists. clean it.\n";
        system "rm -rf $workdir/*";
}else{
        print "$workdir does not exists. build it.\n";
        mkdir "$workdir", 0755 or warn "cannot create $workdir directory:$!";
}

my $RJMapper="perl $scripts";

print "get TE ends from TE database\n";
system "$RJMapper/getTEends.pl $teFile 50 >$workdir/TEends50";#this TE ends of 50 bp is only used to find RJM in this module 
system "$RJMapper/getTEends.pl $teFile $sizeEnd >$outPre.TEends";#this TE ends file will be used to find predicted partner RJM 

print "format TE Base and place it to working directory\n";
my $teBase;
if($tformated ne "0"){
	print "TE databse has been formated. Copy it to working directory\n";
	system "cp $tformated.nhr $tformated.nin $tformated.nsq $workdir";
	$teBase=basename($tformated);
}else{
	print "TE databse does not exists. Create and copy it to working directory\n";
	system "formatdb -i $teFile -pF";
	system "cp $teFile.nhr $teFile.nin $teFile.nsq $workdir";
	$teBase=basename($teFile);
}

print "format alternative TE base and put it to working directory\n";
my $ateBase;
if($ateFile eq ""){
	$ateBase=$teBase;
}else{
	$ateBase=basename($ateFile);
	system "cp $ateFile $workdir/$ateBase";
	system "formatdb -i $workdir/$ateBase -pF";
	print "ateBase=$ateBase\n";
}

print "format query set and place it to working directory\n";
my $queryBase;
if($qformated ne "0"){
	print "query set has been formated. Copy it to working directory\n";
	system "cp $qformated.nhr $qformated.nin $qformated.nsq $workdir";
	$queryBase=basename($qformated);
}else{
	print "query databse does not exists. Create and move it to working directory\n";
	system "formatdb -i $queryFile -pF";
	system "cp $queryFile.nhr $queryFile.nin $queryFile.nsq $workdir";
	$queryBase=basename($queryFile);
}

print "blast TE ends to query set\n";
system "$blast -p blastn -d $workdir/$queryBase -i $workdir/TEends50 -W 50 -b 1000000 -v 1000000 -F F -e 1000 -a $cpuNum -m 8 -o $workdir/TEends2querySet.bls";
print "done blast\n";

print "extract RJMs based on blast results\n";
my $ext=$sizeRJM/2;
system "$RJMapper/getTEEndsMatch.pl $workdir/TEends2querySet.bls 1 $workdir/TEends50 $queryFile $ext >$workdir/getTEEndsMatch";

print "get RJMs (redundant not excluded)\n";
system "$RJMapper/getRJM.pl $workdir/getTEEndsMatch 1 $sizeRJM >$workdir/getRJM";


print "get RJM types (exclude redundant)\n";
system "$RJMapper/getRJMType.pl $workdir/getRJM >$workdir/RJMType";


print "clean RJMs representing internal domain of TEs\n";
system "$blast -p blastn -d $workdir/$ateBase -i $workdir/RJMType -b 1 -v 1 -F F -e 1000 -a $cpuNum -m 8 -o $workdir/RJMType2ATEBase.bls";
system "$RJMapper/cleanGoodHit.pl $workdir/RJMType2ATEBase.bls 0.7 $sizeRJM $workdir/RJMType >$workdir/RJMType.external";


print "blast different RJMs to query set\n";
system "$blast -p blastn -d $workdir/$queryBase -i $workdir/RJMType.external -b 1000000 -v 1000000 -F F -e 1000 -a $cpuNum -m 8 -o $workdir/RJMType2querySet.bls";
print "blast done\n";

print "count RJM copy number\n";
system "$RJMapper/filterBLS.editDist.pl $workdir/RJMType2querySet.bls $sizeRJM $minSim >$workdir/RJMType2querySet.filterBLS$minSim";
system "$RJMapper/countRJM.pl $workdir/RJMType2querySet.filterBLS$minSim $outPre.RJMUniquenessInQuerySet.$minSim >$outPre.RJMCPN.inQuerySet";

print "get unique RJMs in query set\n";
system "$RJMapper/getUniqRJM.countRJMInput.pl $outPre.RJMCPN.inQuerySet $workdir/getRJM $outPre.uniqRJM.inQuerySet.seq >$outPre.uniqRJM.inQuerySet";

print "get query entries that do not contain unique RJMs\n";
system "$RJMapper/getSeqNoUniqRJM.pl $outPre.uniqRJM.inQuerySet $queryFile >$outPre.queryNoUniqRJM";

print "End of RJMDetection.\nMajor output files:\n";
print "(1)\t$outPre.RJMCPN.inQuerySet\n(2)\t$outPre.uniqRJM.inQuerySet\n(3)\t$outPre.uniqRJM.inQuerySet.seq\n(4)\t$outPre.TEends\n";
print "Other output information file:\n";
print "(1)\tPercentage of unique and multi- copy RJMs in query set: $outPre.RJMUniquenessInQuerySet.$minSim\n";
print "(2)\tQuery entries that do not contain unique RJMs: $outPre.queryNoUniqRJM\n";
