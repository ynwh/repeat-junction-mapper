use strict;
if(@ARGV<1){
	print "$0 <getRJM output>\n";
	exit(0);
}

my %rjm;
my %repRJMId;
open fin,"<$ARGV[0]" or die $!;
while(<fin>){
        if(/^\s*$/){
                next;
        }
        chomp;
        my @x=split(/\t/,$_);
        if($x[3]=~/[Nn]{2}/){
		next;
	}
	my $marker=join(" ",sort($x[3],rev($x[3])));
        $rjm{$marker}=$x[3];
	$repRJMId{$marker}="$x[0]---$x[1]---$x[2]";
}
close fin;

foreach(sort keys %rjm){
	print ">$repRJMId{$_}\n$rjm{$_}\n";
}

sub rev{
        my $x=reverse($_[0]);
        $x=~tr/ATCG/TAGC/;
        $x=~tr/atcg/tagc/;
        return($x);
}

