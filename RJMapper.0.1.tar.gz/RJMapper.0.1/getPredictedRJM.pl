use strict;

if(@ARGV<5){
	print "$0 <unmapped query sequence ID> <unique RJM in query> <TE ends sequence> <size of predicted LTR ends (<=50 bp)> <output dir>\n";
	exit(0);
}

my $output=$ARGV[4];
if(-e "$output"){
}else{
	print "$output does not exists. Exit.\n";
	exit(1);
}

my $len=$ARGV[3];

## read in TE ends, get rid of redundancy by family and terminal
#print "read in TE ends file\n";
open fin, "<$ARGV[2]" or die $!;
my $label;my $seq;my %ltrEnds;
$/=">";
$label=<fin>;
#remove the comment lines above first entry
$/="\n";
while($label=<fin>){
	$label =~ s/^>//;
	$label =~ s/\s*$//;
	$/=">";
	$seq=<fin>;
	$/="\n";
	$seq =~ s/>$//;
	$seq =~ s/\s+//g;
	my @x=split(/\s+/,$label);
	my $famID=(split(/_/,$x[0]))[0]."_".(split(/_/,$x[0]))[1];
        my $ter=(split(/--/,$x[0]))[-1];
        my $family=$famID."__".$ter;
	if($ter eq "A"){
		$seq=substr($seq,0,$len);
	}else{
		$seq=substr($seq,-1*$len,$len);
	}
        $ltrEnds{$family}{$seq}=1;# exclude redundancy
}
close fin;

#foreach my $famTer(keys %ltrEnds){
#	foreach my $seq(keys %{$ltrEnds{$famTer}}){
#		print "$famTer\t$seq\n";
#	}
#}


##get unique RJMs in unmapped sequences
#print "read in unmapped query sequence ids\n";
my %unmapped;
open fin,"<$ARGV[0]" or die $!;
while(<fin>){
	chomp;
	if(/^\s*$/){
		next;
	}
	$unmapped{(split(/\s+/,$_))[0]}=1;
}
close fin;

#print "get unique RJMs in unmapped query sequences\n";
my %queryRJM;
open fin,"<$ARGV[1]" or die $!;
while(<fin>){
	chomp;
	if(/^\s*$/){
		next;
	}
	if(exists $unmapped{(split(/\s+/,$_))[0]}){
		$queryRJM{$_}=1;
	}
}
close fin;

#foreach(keys %queryRJM){
#	print $_."\n";
#}

## predict RJMs
#print "predict RJMs\n";
my %predict;#sequence of predicted LTR ends + TSD
my %predInfo;#family and terminal information of predicted LTR ends + TSD
my %shortID;#map full rjm id to short ID for sequence used for blast search

foreach my $rjm(keys %queryRJM){
#	print "$rjm\n";
	my ($seqId,$start,$stop,$str,$famTerOrientTsd)=split(/\s+/,$rjm);
	my $firstFam=(split(/,/,$famTerOrientTsd))[0];
	my ($famID,$ter,$orient,$tsd)=split(/__/,$firstFam);
#	print "$famID,$ter,$orient,$tsd\n";
	my $rjmOnefam="$seqId\t$start\t$stop\t$str\t$firstFam";
	if($orient eq "-"){
		$tsd=rev($tsd);
	}
	my $mateTer;
	if($ter eq "A"){
		$mateTer="B";
	}else{
		$mateTer="A";
	}
	my $otherEnd=$famID."__".$mateTer;
#	print "$firstFam: predicted partner = $otherEnd\n";
	$predInfo{"$seqId---$start---$stop"}=$otherEnd;
	$shortID{"$seqId---$start---$stop"}=$rjmOnefam;
	if(exists $ltrEnds{$otherEnd}){
		foreach my $s(keys %{ $ltrEnds{$otherEnd} }){
			my $endTsd;
			if($mateTer eq "A"){
				$endTsd="$tsd$s";
			}else{
				$endTsd="$s$tsd";
			}
			$predict{"$seqId---$start---$stop"}{$endTsd}=1;#exclude redundancy
		}
	}else{
		print "$firstFam: the other end does not found\n";
	}
}

open fout,">$output/predInfo";
foreach(keys %predInfo){
	print fout "$_\t$predInfo{$_}\n";
}
close fout;

open fout,">$output/idmap" or die $!;
foreach(keys %shortID){
	print fout "$_\t<-->\t$shortID{$_}\n";
}
close fout;

#prepare sequences of predicted end+TSD for BLASTN against reference set
open fout,">$output/predict" or die $!;
foreach my $rjm(keys %predict){
#	print "$rjm: search its predicted LTR end + TSD\n";
	my $n=0;
	foreach my $str(keys %{$predict{$rjm}}){
		++$n;
		print fout ">$rjm---$n\n$str\n"; 
	}
}
close fout;

sub rev{
	my $x=reverse($_[0]);
	$x=~tr/ATCG/TAGC/;
	$x=~tr/atcg/tagc/;
	return($x);
}
