use strict;
use File::Basename;
use Getopt::Std;
getopts("i:j:u:S:n:r:o:c:h:b:B:E:l:m:x:F:");
use vars qw($opt_i $opt_j $opt_u $opt_m $opt_n $opt_r $opt_o $opt_c $opt_h $opt_b $opt_B $opt_E $opt_l $opt_S $opt_x $opt_F);

my $queryFile=defined $opt_i ? $opt_i : "";
my $refFile=defined $opt_j ? $opt_j : "";
my $uniqRJMQuery=defined $opt_u ? $opt_u : "";
my $uniqRJMQuerySeq=defined $opt_m ? $opt_m : "";
my $outPre=defined $opt_o ? $opt_o : "";
my $scripts=defined $opt_b ? $opt_b : "";
my $easyfig=defined $opt_E ? $opt_E : "";
my $ratio=defined $opt_r ? $opt_r : "2";
my $minSuRJM=defined $opt_n ? $opt_n : "1";
my $cpuNum=defined $opt_c ? $opt_c : "4";
my $blast=defined $opt_B ? $opt_B : "blastall";
my $help=defined $opt_h ? $opt_h : "";
my $sizeRJM=defined $opt_l ? $opt_l : 50;
my $minSim=defined $opt_S ? $opt_S : 1;
my $noUniqMarker=defined $opt_x ? $opt_x : "";
my $formated=defined $opt_F ? $opt_F : 0;


usage() if((!$scripts)||(!$uniqRJMQuery)
           ||(!$uniqRJMQuerySeq)||(!$queryFile)
           ||(!$refFile)||(!$outPre)||(!$easyfig)||(!$noUniqMarker)||($help));

sub usage{
	print "Usage: program <options>\n";
	print "-b     STRING     Dir that the RJMapper program installed\n";
	print "                  [required]\n";
	print "-i     STRING     Query set file path [required]\n";
	print "-j     STRING     Reference set file path [required]\n";
	print "-u     STRING     Path of unique RJMs information in query set\n";
	print "                  [required]\n";
	print "-m     STRING     Path of unique RJMs sequence in query set\n";
	print "                  [required]\n";
	print "-E     STRING     Program easyFig commend path [required]\n";
	print "-o     STRING     Output prefix [required]\n";
	print "-x     STRING     Path of query sequence IDs without unique RJMs\n";
	print "                  [required]\n";
	print "-l     INT        Size of RJM based on output from RJMDetection\n";
	print "                  [default 50]\n";
	print "-S     FLOAT      Minimum similarity value when counting copy\n";
	print "                  number of RJM [default 1.0]\n";
	print "-n     INT        Minimum number of share unique RJMs (suRJMs)\n";
	print "                  [default 1]\n";
	print "-r     INT        Mapping d/query d. d=distance between most\n";
	print "                  left and right suRJMs [default 2]\n";
	print "-c     INT        CPU number when compute BLAST [default 4]\n";
	print "-B     STRING     BLAST commend path [default blastall]\n";
	print "-F     0/STRING   Path to blast database of reference set. If 0,\n";
	print "                  not formated, and -j must be used. If STRING,\n";
	print "                  path to the database [default 0]\n";
	print "-h     STRING     Show this help message\n";
	exit(0);
}

sub usage1(){
	print "-j and -F must match: if -F==0, -j must be the path of file\n";
	print "of referecne sequences. If -F is a formatdb path, -j will be\n";
	print "neglected\n";
	exit(0);
}

my $workdir="RJMDirectMapping";

print "build working directory: $workdir\n";
if(-e "$workdir"){
	print "$workdir exists. clean it.\n";
	system "rm -rf $workdir/*";
}else{
	print "$workdir does not exists. build it.\n";
	mkdir "$workdir", 0755 or warn "cannot create $workdir directory:$!";
}

my $RJMapper="perl $scripts";
print "format reference set and move it to working directory\n";
my $refBase;
if($formated ne "0"){
	print "reference set has been formated. Move it to working directory\n";
	system "cp $formated.nhr $formated.nin $formated.nsq $workdir";
	$refBase=basename($formated);
}else{
	print "reference database does not exists. Create and move it to working directory\n";
	system "formatdb -i $refFile -pF";
	system "mv $refFile.nhr $refFile.nin $refFile.nsq $workdir";
	$refBase=basename($refFile);
}

print "blast unique RJMs that are in query to reference set\n";
system "$blast -p blastn -d $workdir/$refBase -i $uniqRJMQuerySeq -b 1000000 -v 1000000 -F F -e 1000 -a $cpuNum -m 8 -o $workdir/uniqRJMQuery2Ref.bls";
print "done blast.\n";

print "filter blast result to get highly similar matches of unique RJMs in query set\n";
system "$RJMapper/filterBLS.editDist.pl $workdir/uniqRJMQuery2Ref.bls $sizeRJM $minSim >$workdir/uniqRJMQuery2Ref.filterBLS$minSim";

print "construct shared unique RJM mapping between query and reference sets\n";
system "$RJMapper/uniqRJMMap.pl $workdir/uniqRJMQuery2Ref.filterBLS$minSim $uniqRJMQuery >$outPre.sharedUniqRJMMap";

print "evaluate mapping region by distribution of share unique RJMs\n";
system "$RJMapper/RJMMapToRef.directMap.pl $outPre.sharedUniqRJMMap $queryFile $outPre $ratio $minSuRJM $noUniqMarker > $workdir/log.RJMMapToRef.directMap";

print "output alingments of mapping regions for inspection\n";
my $inspectDirWellMapped="$outPre.wellMapped.inspectAln";
system  "$RJMapper/visualizationMapping.pl $outPre.sharedUniqRJMMap $outPre.wellMapped $queryFile $refFile $inspectDirWellMapped \'$easyfig\' \'$RJMapper\'";
my $inspectDirOrientIssue="$outPre.markerOrentationInconsistent.inspectAln";
system "$RJMapper/visualizationMapping.pl $outPre.sharedUniqRJMMap $outPre.markerOrentationInconsistent $queryFile $refFile $inspectDirOrientIssue \'$easyfig\' \'$RJMapper\'";

print "add alignment quality info to mapped sequences\n";
system "$RJMapper/addAlnQual.pl $outPre.wellMapped $inspectDirWellMapped >$outPre.wellMapped.addAlnQual\n";
system "$RJMapper/addAlnQual.pl $outPre.markerOrentationInconsistent $inspectDirOrientIssue >$outPre.markerOrentationInconsistent.addAlnQual\n";


print "End of RJMDirectMapping.\nMajor output files:\n";
print "(1)\tInformation of mapped query seuences:\n";
print "(a)\tSequences mapped well: $outPre.wellMapped.addAlnQual\n";
print "(b)\tSequences mapped well, but RJM orientation inconsistent: $outPre.markerOrentationInconsistent.addAlnQual\n";
print "(2)\tUnmapped query sequences (sequence without enough shared unique markers): $outPre.unmapped\n";
print "(3)\tQuery sequences do not have mapping region of valid size: $outPre.nonLocalMapped\n";
print "(4)\tTwo dirs containing alignments of mapped query sequences:\n";
print "(a)\t$outPre.wellMapped.inspectAln\n";
print "(b)\t$outPre.markerOrentationInconsistent.inspectAln\n";
print "(5)\tInformation of shared unique markers: $outPre.sharedUniqRJMMap\n";

