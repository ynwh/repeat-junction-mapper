use strict;
if(@ARGV<2){
	print "$0 <uniqRJM result> <query sequence>\n";
	exit(0);
}

my %haveUniqRJM;
open fin,"<$ARGV[0]" or die $!;
while(<fin>){
	if(/^\s*$/){
		next;
	}
	$haveUniqRJM{(split(/\s+/,$_))[0]}=1;
}
close fin;

open fin,"<$ARGV[1]" or die $!;
while(<fin>){
	if(/^>(\S+)/){
		my $id=$1;
		if(!exists $haveUniqRJM{$id} ){
			print "$id\tnoUniqueRJM\n";
		}
	}
}
close fin;

