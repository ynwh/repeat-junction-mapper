use strict;
if(@ARGV<3){
	print "$0 <bls> <sim> <RJM length> <seq>\n";
	exit(0);
}

my $sim=$ARGV[1];
my $rjmSize=$ARGV[2];
my %hit;
open fin,"<$ARGV[0]" or die $!;
while(<fin>){
	if(/^\s*$/){
		next;
	}
	my @x=split(/\t/,$_);
	my $len=$x[7]-$x[6]+1;
	my $d=($x[4]+$x[5])/$rjmSize;
	if( (1-$d) >= $sim && $len/$rjmSize >= $sim){
	# || ($x[6]>$rjmSize/2-50 && $x[7]>$rjmSize/2+50)) ){
		$hit{$x[0]}=1
	}	
}
close fin;

open fin, "<$ARGV[3]" or die "Cannot open $ARGV[1]: $!";
my $label;my $seq;
$/=">";
$label=<fin>;
#remove the comment lines above first entry
$/="\n";
while($label=<fin>){
	$label =~ s/^>//;
	$label =~ s/\s*$//;
	$/=">";
	$seq=<fin>;
	$/="\n";
	$seq =~ s/>$//;
	$seq =~ s/\s+//g;
	my @lab=split(/\s+/,$label);
	if( !exists $hit{$lab[0]}){
		print ">$label\n$seq\n";
	}
}
close fin;

