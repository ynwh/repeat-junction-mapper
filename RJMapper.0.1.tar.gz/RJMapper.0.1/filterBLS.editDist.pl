use strict;
use File::Basename;

if(@ARGV<3){
	print "$0 <bls m8> <RJM size> <min similarity (0-1)>\n";
	print "similarity = 1-edit_distance=1-(mismatch + gap)/RJM_size\n";
	exit(0);
}

my $rjmSize=$ARGV[1];
my $sim=$ARGV[2];

open fin,"<$ARGV[0]" or die $!;
while(<fin>){
	if(/^\s*$/){
		next;
	}
	my @x=split(/\t/,$_);
	my $d=($x[4]+$x[5])/$rjmSize;
	my $len=$x[7]-$x[6]+1;
	if((1-$d) >= $sim && $len/$rjmSize >= $sim){
		print $_;
	}
}
close fin;
