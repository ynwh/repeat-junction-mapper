use strict;
use File::Basename;
if(@ARGV<3){
	print "$0 <getTEEndsMatch output> <RJM starts> <RJM size (even number)>\n";
	print "<RJM start> count from string in col 8 of file input as parameter 1>\n";
	exit(0);
}
my $rjmst=$ARGV[1];
my $rjmlen=$ARGV[2];

#my $f=basename($0);
#my $logfile="log.$f";
#$logfile=~s/\.pl$//;
#open logs, ">$logfile" or die $!;


my %rjmSeq;
my %rjmInfo;
my %rjm;
open fin,"<$ARGV[0]" or die $!;
while(<fin>){
	if(/^\s*$/){
		next;
	}
	my @x=split(/\s+/,$_);
	my $famID;
	if($x[0]=~/^([RLCGX]{3}_.+?)[\_\-]/){
		$famID=$1;
	}
	my $ter=(split(/--/,$x[0]))[-1];
	my $family=$famID."__".$ter."__".$x[2]."__".$x[5];
	my $ext=substr($x[7],$rjmst-1,$rjmlen); #RJM of equal size around the TE terminal
	if($ext=~/[Nn]{2}/){next;}
	if(length($ext)<$rjmlen){next;}
	my $rjmpos1;
	my $rjmpos2;
	if($x[2] eq "+" && $ter eq "A"){
		$rjmpos1=$x[3]-$rjmlen/2;
		$rjmpos2=$x[3]+$rjmlen/2-1;
	}elsif($x[2] eq "-" && $ter eq "A"){
		$rjmpos1=$x[4]-$rjmlen/2+1;
		$rjmpos2=$x[4]+$rjmlen/2;
	}elsif($x[2] eq "+" && $ter eq "B"){
		$rjmpos1=$x[4]-$rjmlen/2+1;
		$rjmpos2=$x[4]+$rjmlen/2;
	}elsif($x[2] eq "-" && $ter eq "B"){
		$rjmpos1=$x[3]-$rjmlen/2;
		$rjmpos2=$x[3]+$rjmlen/2-1;
	}else{
		#print logs "unexpected terminals: $_\n";
	}
	$rjm{"$x[1]\t$rjmpos1\t$rjmpos2\t$ext"}.="$family;";
}
close fin;

foreach my $x(keys %rjm){
	my %uniq;
	foreach(split(/;/,$rjm{$x})){
		$uniq{$_}=1;
	}
	my $famID=join(",",sort keys %uniq);
	print "$x\t$famID\n";
}


#sort RJM by position
#open rjmseq, ">$ARGV[3]" or die $!;
#foreach my $x(sort by_pos keys %rjm){
#	print "$_\t$rjmSeq{$_}\t";
#	my %uniq;
#	foreach(split(/;/,$rjm{$x})){
#		$uniq{$_}=1;
#	}
#	print join(";",sort keys %uniq)."\n";
#	print  "$x\t".join(",",sort keys %uniq)."\n";
#	print $rjm{$_}."\n";
#	my @info=split(/\t/,$x);
#	my $seq=pop(@info);
#	my $id=join("---",@info);
#	print rjmseq ">$id\n$seq\n";
#}
#close rjmseq;


#close logs;

sub by_pos{
	my ($seq1,$begin1,$stop1,$str1)=split(/\s+/,$a);
	my ($seq2,$begin2,$stop2,$str2)=split(/\s+/,$b);
	my $mid1=($begin1+$stop1)/2;
	my $mid2=($begin2+$stop2)/2;
	if($seq1 lt $seq2){
		-1;
	}elsif($seq1 gt $seq2){
		1;
	}else{
		{$mid1<=>$mid2}
	}
}

