use strict;
if(@ARGV<2){
	print "$0 <information file> <aln quality dir>\n";
	exit(0);
}

my %perc;
my $d=$ARGV[1];
opendir dir,"$ARGV[1]" or die $!;
foreach my $sub(readdir dir){
	if(-e "$d/$sub/$sub.getMatchedRegion"){
		open fin,"<$d/$sub/$sub.getMatchedRegion" or die $!;
		my @x=split(/\s+/,<fin>);
		close fin;
		$perc{$x[0]}="$x[5]\t$x[11]";
	}
}
closedir dir;

open fin,"<$ARGV[0]" or die $!;
foreach(<fin>){
	chomp;
	my $id=(split(/\s+/,$_))[0];
	if(exists $perc{$id}){
		print "$_\t$perc{$id}\n";
	}else{
		print "$_\tNA\tNA\n";
	}
}
close fin;