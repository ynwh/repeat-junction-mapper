use strict;
use File::Basename;
use Getopt::Std;
getopts("j:I:u:T:s:o:h:F:b:B:c:");
use vars qw($opt_I $opt_j $opt_u $opt_T $opt_o $opt_b $opt_s $opt_c $opt_B $opt_h $opt_F);
my $queryId=defined $opt_I ? $opt_I : "";
my $uniqRJMQuery=defined $opt_u ? $opt_u : "";
my $teEnd=defined $opt_T ? $opt_T : "";
my $outPre=defined $opt_o ? $opt_o : "";
my $scripts=defined $opt_b ? $opt_b : "";
my $sizeEnd=defined $opt_s ? $opt_s : 50;
my $cpuNum=defined $opt_c ? $opt_c : 4;
my $blast=defined $opt_B ? $opt_B : "blastall";
my $help=defined $opt_h ? $opt_h : "";
my $formated=defined $opt_F ? $opt_F : 0;
my $refFile=defined $opt_j ?$opt_j : "";

usage() if((!$scripts)||(!$queryId)||(!$uniqRJMQuery)||(!$teEnd)||(!$outPre)||($help));
usage1() if($formated eq "0" && !$refFile);

sub usage{
	print "Usage: program <options>\n";
	print "-b     STRING     Dir that the RJMapper program installed\n";
	print "                  [required]\n";
	print "-I     STRING     Query sequence ID file path [required]\n";
	print "-u     STRING     Path of unique RJMs information in query set\n";
	print "-T     STRING     LTR ends file path [required]\n";
	print "-o     STRING     Output prefix [required]\n";
	print "-j     STRING     Reference set file path. Must provided if -F 0\n";
	print "-s     INT        Size of TE ends in prediction. This value\n";
	print "                  should <= TE end length in file assigned to\n";
	print "                  -T [default 50]\n";
	print "-c     INT        CPU number when compute BLAST [default 4]\n";
	print "-B     STRING     BLAST commend path [default blastall]\n";
	print "-F     0/STRING   Path to blast database of reference set. If 0,\n";
	print "                  not formated, and -j must be used. If STRING,\n";
	print "                  path to the database [default 0]\n";
	print "-h     STRING     Show this help message\n";
	exit(0);
}

sub usage1(){
	print "-j and -F must match: if -F==0, -j must be the path of file\n";
	print "of referecne sequences. If -F is a formatdb path, -j will be\n";
	print "neglected\n";
	exit(0);
}

my $workdir="PartnerRJMSearching";
print "build working directory: $workdir\n";
if(-e "$workdir"){
	print "$workdir exists. clean it.\n";
	system "rm -rf $workdir/*";
}else{
	print "$workdir does not exists. build it.\n";
	mkdir "$workdir", 0755 or warn "cannot create $workdir directory:$!";
}

my $refSet;
if($formated ne "0"){
	print "reference set has been formated. Move it to working directory\n";
	system "cp $formated.nhr $formated.nin $formated.nsq $workdir";
	$refSet=basename($formated);
}else{
	print "format reference set and move it to working directory\n";
	system "formatdb -i $refFile -pF";
	system "mv $refFile.nhr $refFile.nin $refFile.nsq $workdir";
	$refSet=basename($refFile);
}

my $RJMapper="perl $scripts";
print "predict partner RJMs based on unique RJMs in query sequences\n";
system "$RJMapper/getPredictedRJM.pl $queryId $uniqRJMQuery $teEnd $sizeEnd $workdir";
print "blast predicted partner RJMs to reference sequences\n";
system "$blast -p blastn -d $workdir/$refSet -i $workdir/predict -b 1000000 -v 1000000 -F F -e 1000 -a $cpuNum -m 8 -W $sizeEnd -o $workdir/predict2Ref.bls";
print "blast done.\n";
print "get mapping information based on blast result.\n";
system "$RJMapper/gatherPartnerRJMInfo.pl $workdir/predict2Ref.bls $workdir/predInfo $workdir/idmap $workdir/predict $sizeEnd $queryId $outPre";
print "End of partnerRJMSearching.\nMajor output files:\n";
print "(1)\t$outPre.predictUniqueInRef\n";
print "(2)\t$outPre.predictNotuniqueInRef\n";
print "(3)\t$outPre.seqPredictNoHit\n";
